import { initializeApp } from "firebase/app";

// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyDWt7Eg6ViGAm7UWRh4GyvIQq4xETsbLLg",
  authDomain: "register-d5d58.firebaseapp.com",
  projectId: "register-d5d58",
  storageBucket: "register-d5d58.appspot.com",
  messagingSenderId: "281619176059",
  appId: "1:281619176059:web:7d184a37f3813f1402e0de",
};
