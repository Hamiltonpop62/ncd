import { configureStore } from "@reduxjs/toolkit";
import noteSlice from "./slices/noteSlice";
import counterSlice from "./slices/counterSlice";
import formSlice from "./slices/formSlice";

export const store = configureStore({
  reducer: {
    note: noteSlice,
    counter: counterSlice,
    formdata: formSlice,
  },
});
