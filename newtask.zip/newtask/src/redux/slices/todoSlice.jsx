import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const getTodos = createAsyncThunk("todos/getTodos", async () => {

    const response = await fetch("https://jsonplaceholder.typicode.com/todos");
    const data = await response.json();
    return data;
}
);
export const todoSlice = createSlice({
    name:"todo",
    initialState:{
        todos:[
        {id:1, title:"todo1", completed:false},
        {id:2, title:"todo2", completed:false},
        ],
    status:null
    },
})