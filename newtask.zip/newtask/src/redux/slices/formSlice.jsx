import { createSlice } from "@reduxjs/toolkit";

const initialState={
    data:[]
}
export const formSlice = createSlice({
name:"formdata",
initialState,
reducers:{
    addData:(state,action)=>{
        state.data.push(action.payload)
    },
    removeData:(state,action)=>{
        state.data= state.data.filter((data)=>data.id!==action.payload)
    }
}
}) 
export const {addData,removeData} = formSlice.actions
export default formSlice.reducer;