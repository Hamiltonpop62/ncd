import React, { useState, useEffect } from "react";
import { Button, Col, Form, InputGroup, Row, Modal } from "react-bootstrap";

const ApprovalModal = ({
    showModal,
    closeModal,
    selectedPatientId,
    handleApproval,
  }) => {
    const [reasonInput, setReasonInput] = useState("");
    const [approvalInput, setApprovalInput] = useState("");
    const handleApprovalChange = (event) => {
        setApprovalInput(event.target.value);
      };
    const handleReasonChange = (event) => {
        setReasonInput(event.target.value);
      };
  return (
    <div>
    <Modal show={showModal} onHide={closeModal}>
    <Modal.Header closeButton>
      <Modal.Title>Enter Reason</Modal.Title>
    </Modal.Header>
    <Modal.Body>
      <Form.Group controlId="reasonInput">
        <Form.Label>Patient ID</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter reason"
          value={selectedPatientId}
          disabled
        />
      </Form.Group>


      <Form.Group controlId="reasonInput" className="mb-3 mt-3">
        <Form.Label>Approval</Form.Label>
        <Form.Select onChange={handleApprovalChange} value={approvalInput}>
        <option value="">Select </option>
        <option value="1">Approved</option>
        <option value="2">Rejected</option>
      </Form.Select>
        </Form.Group>
      <Form.Group controlId="reasonInput">
        <Form.Label>Reason</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter reason"
          value={reasonInput}
          onChange={handleReasonChange}
        />
        
      </Form.Group>
    </Modal.Body>
    <Modal.Footer>
      <Button variant="secondary" onClick={closeModal}>
        Close
      </Button>
      <Button variant="primary" onClick={() => handleApproval(reasonInput, approvalInput)}>
        Approve
      </Button>
    </Modal.Footer>
  </Modal>
    </div>
  )
}

export default ApprovalModal