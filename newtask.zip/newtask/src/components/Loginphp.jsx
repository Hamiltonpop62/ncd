import axios from "axios";
import React, { useState } from "react";
import { Col, Image } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import loginimage from "../images/ncdpage.png";

const Loginphp = () => {
  const history = useNavigate();
  const [formData, setFormData] = useState({
    login: true,
    username: "",
    password: "",
  });
  const [apiResult, setApiResult] = useState(null);
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    if (formData.username === "" || formData.password === "") {
      setApiResult("Please fill all the fields");
      return;
    }
    try {
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const apiResponse = await axios.post(apiUrl, formData, {
        headers: {
          AuthKey: `${
            JSON.parse(localStorage.getItem("userData"))?.token
          }`,
        },
      });
      setApiResult(apiResponse.data.result);
      if (apiResponse.data.result === "success") {
        const userData = {
          username: apiResponse.data.data[0].username,
          userlevel: apiResponse.data.data[0].userlevel,
          token:apiResponse.data.token
        };
        localStorage.setItem("userData", JSON.stringify(userData));
        setApiResult("success");
        if (userData.userlevel === '1') {
          history("/Bedavailable"); // Redirect to bedavailability.jsx
        } else if (userData.userlevel === '2') {
          history("/patientlist"); // Redirect to patientlist
        }
      } else if (apiResponse.data.result === "failed") {
        setApiResult("Invalid Credentials");
      }
      console.log(localStorage.getItem("token"));
      console.log(apiResponse.data);
    } catch (error) {
      console.error("Error calling the API:", error);
    }
    console.log(formData);
  };
  return (
    <div>
      <div className="d-flex">
        <Col md={5} className="loginbg1">
          <Image src={loginimage} style={{ width: "100%" }} />
        </Col>
        <Col xl={7} className="pt-5">
          <div className="pt55 px-4">
            <Col xl={6} className="mx-auto  cardbshadow px-3 py-4">
              <h3 className="text1 font-weight-bold mb-3 ">Login</h3>
              {apiResult && (
                <div
                  className={`mb-2 text-center text-${
                    apiResult === "success" ? "success" : "danger"
                  }`}
                >
                  {apiResult}
                </div>
              )}
              <form onSubmit={handleSubmit}>
                <div className="form-group mb-3" id="id1">
                  <label
                    htmlFor="exampleInputEmail1 text1"
                    style={{
                      fontWeight: 500,
                      fontSize: "15px",
                    }}
                    className="text2"
                  >
                    Email/Username
                  </label>
                  <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleInputChange}
                    className="form-control"
                    placeholder="Enter Username "
                    autoComplete="off"
                  />
                </div>
                <div id="id2">
                  <label
                    htmlFor="exampleInputEmail1 text1"
                    style={{
                      fontWeight: 500,
                      fontSize: "15px",
                    }}
                    className="text2"
                  >
                    Password
                  </label>
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    className="form-control"
                    placeholder="Enter Password"
                    autoComplete="off"
                  />
                </div>
                <button
                  type="submit"
                  className="btn btn-primary btn1 w-100 mt-5 mb-4"
                >
                  Login
                </button>
              </form>
            </Col>
          </div>
          <div className="bgimage"></div>
        </Col>
      </div>
    </div>
  );
};

export default Loginphp;
