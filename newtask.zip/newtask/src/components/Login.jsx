import React, { useState, useEffect } from "react";
import { Button, Col, Form } from "react-bootstrap";
import {
  getAuth,
  signInWithEmailAndPassword,
  signInWithPopup,
} from "firebase/auth";
import { GoogleAuthProvider } from "firebase/auth";
import { Link } from "react-router-dom";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [successmessage, setSuccessMessage] = useState("");
  const [userLocation, setUserLocation] = useState(null);

  const auth = getAuth();
  const provider = new GoogleAuthProvider();

  const getLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting user location:", error);
        }
      );
    } else {
      console.error("Geolocation is not available in this browser.");
    }
  };

  useEffect(() => {
    getLocation();
  }, []);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      await signInWithEmailAndPassword(auth, username, password);
      setSuccessMessage("Login successful");
      setTimeout(() => {
        setSuccessMessage(null);
      }, 5000);
    } catch (error) {
      if (error.code === "auth/user-disabled") {
        setErrorMessage(
          "Your account has been disabled. Please contact support."
        );
        setTimeout(() => {
          setErrorMessage(null);
        }, 5000);
      } else if (error.code === "auth/invalid-login-credentials") {
        setErrorMessage("Invalid Login Credentials. Please try again. ");
        setTimeout(() => {
          setErrorMessage(null);
        }, 5000);
      } else {
        console.error(error);
        setErrorMessage("An error occurred while Login. Please try again.");
        setTimeout(() => {
          setErrorMessage(null);
        }, 5000);
      }
      setSuccessMessage("");
    }
  };

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, provider)
        .then((result) => {
          // This gives you a Google Access Token. You can use it to access the Google API.
          const credential = GoogleAuthProvider.credentialFromResult(result);
          const token = credential.accessToken;
          // The signed-in user info.
          const user = result.user;
          console.log(user);
          // IdP data available using getAdditionalUserInfo(result)
          // ...
        })
        .catch((error) => {
          // Handle Errors here.
          const errorCode = error.code;
          const errorMessage = error.message;
          // The email of the user's account used.
          const email = error.customData.email;
          // The AuthCredential type that was used.
          const credential = GoogleAuthProvider.credentialFromError(error);
          // ...
        });
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <Col
        md={5}
        className="mx-auto mt-4 border-1 px-3 py-3 rounded"
        style={{ boxShadow: "-1px 2px 5px 5px #efefef" }}
      >
        <h2 className="mb-3" style={{ fontWeight: "600" }}>
          Login
        </h2>
        <Form onSubmit={handleLogin}>
          {errorMessage && (
            <p p className="alert alert-danger mt-3" role="alert">
              {errorMessage}
            </p>
          )}
          {successmessage && (
            <p className="alert alert-success" role="alert">
              {successmessage}
            </p>
          )}

          <Form.Group controlId="formBasicEmail" className="mb-3">
            <Form.Label>Username</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter username"
              onChange={(e) => setUsername(e.target.value)}
            />
          </Form.Group>
          <Form.Group controlId="formBasicPassword" className="mb-3">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Enter password"
              onChange={(e) => setPassword(e.target.value)}
            />
          </Form.Group>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </Form>
        <div className="mt-3">
          <Link to="/signup" className="mt-2">
            Don't have an account? Signup
          </Link>
        </div>
        <Button onClick={signInWithGoogle}>Sign In With Google</Button>
      </Col>
    </div>
  );
};

export default Login;
