import React from "react";
import { Form, Button } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { addData } from "../redux/slices/formSlice";

const ReactForm = () => {
  const formvalue = useSelector((state) => state.formdata.data);
  const dispatch = useDispatch();
  const [data, setData] = React.useState({
    name: "",
    email: "",
    phone: "",
  });
  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addData(data));
    setData({ name: "", email: "", phone: "" });
  };
  console.log(formvalue);

  return (
    <div>
      <Form onSubmit={handleSubmit} className="col-md-6 mx-auto">
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter name"
            name="name"
            value={data.name}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            name="email"
            value={data.email}
            onChange={handleChange}
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Phone</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter phone"
            name="phone"
            value={data.phone}
            onChange={handleChange}
          />
        </Form.Group>
        <Button variant="primary" type="submit">
          Submit
        </Button>
      </Form>

      <div>
      {formvalue.map((data) => (
    
        <div key={data.id}>
          <h6>{data.name}</h6>
          <h6>{data.email}</h6>
          <h6>{data.phone}</h6>
        </div>
      ))
    }
      </div>
    </div>
  );
};

export default ReactForm;
