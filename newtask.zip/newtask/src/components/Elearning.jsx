import React from 'react'

const Elearning = () => {
  return (
    <div>Elearning</div>
  )
}

export default Elearning