import React, { useState } from "react";
import {
  Button,
  Form,
  FormControl,
  FormGroup,
  FormLabel,
  Table,
} from "react-bootstrap";

const Weather = (props) => {
  const [weather, setWeather] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    country: "",
    city: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const APIKEY = "08707709da72f3574b3a6a28d41d13d9";

  async function getWeather(e) {
    e.preventDefault();
    if (form.country === "") {
      alert("Please Enter Country");
    } else if (form.city === "") {
      alert("Please Enter City");
    } else {
      const apiCall = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${form.city},${form.country}&APPID=${APIKEY}`
      );
      const response = await apiCall.json();
      setWeather({ response });
      console.log(response);
      setForm({
        country: "",
        city: "",
      });
      setLoading(false);
    }
  }

  return (
    <div className="">
      <div className="col-md-6 mx-auto py-4 px-4 br1">
        <h3 className="text-center mb-3 getw">
          <b>Get Weather</b>
        </h3>
        <Form>
          <FormGroup className="mb-3">
            <FormLabel>Country</FormLabel>
            <FormControl
              type="text"
              placeholder="Enter Country"
              name="country"
              value={form.country}
              onChange={handleChange}
            />
          </FormGroup>
          <FormGroup className="mb-3">
            <FormLabel>City</FormLabel>
            <FormControl
              type="text"
              placeholder="Enter City"
              name="city"
              value={form.city}
              onChange={handleChange}
            />
          </FormGroup>
          <Button
            className="btn btn-primary-outline"
            type="submit"
            onClick={getWeather}
          >
            Submit
          </Button>
        </Form>
      </div>
      <div className="col-md-6 mx-auto py-4 px-4">
        {loading && <h3 className="text-center mb-3">Loading please wait..</h3>}
        {weather.response && (
          <Table>
            <thead>
              <tr>
                <td>City Name</td>
                <td>Temp</td>
                <td>Description</td>
                <td>Deg</td>
                <td>Speed</td>
                <td>ID</td>
              </tr>
            </thead>
            <tr>
              <td>{weather.response.name}</td>
              <td>{weather.response.main.temp}</td>
              <td>{weather.response.weather[0].description}</td>
              <td>{weather.response.wind.deg}</td>
              <td>{weather.response.wind.speed}</td>
              <td>{weather.response.id}</td>
            </tr>
          </Table>
        )}
      </div>
    </div>
  );
};

export default Weather;
