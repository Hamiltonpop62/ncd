import React, { useState, useEffect } from "react";

const LocationDisplay = () => {
  const [userLocation, setUserLocation] = useState(null);
  const [areaName, setAreaName] = useState(null);

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ latitude, longitude });
          getAreaName(latitude, longitude);
        },
        (error) => {
          console.error('Error getting user location:', error);
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
    }
  };

  const getAreaName = (latitude, longitude) => {
    // Use Geolocation API to fetch approximate address information
    fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`)
      .then(response => response.json())
      .then(data => {
        if (data.locality) {
          setAreaName(data.locality);
        } else {
          console.error('Area name not found in response.');
        }
      })
      .catch(error => {
        console.error('Error fetching area name:', error);
      });
  };

  return (
    <div>
      <button onClick={getUserLocation}>Get User Location</button>
      {userLocation && (
        <div>
          <h2>User Location</h2>
          <p>Latitude: {userLocation.latitude}</p>
          <p>Longitude: {userLocation.longitude}</p>
          {areaName && <p>Area: {areaName}</p>}
        </div>
      )}
    </div>
  );
};

export default LocationDisplay;
