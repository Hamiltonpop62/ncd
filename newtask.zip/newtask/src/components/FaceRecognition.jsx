import React, { useRef } from "react";
import Webcam from "react-webcam";
import * as faceapi from "face-api.js";

const FaceRecognition = ({ onCapture }) => {
  const webcamRef = useRef(null);

  const loadModels = async () => {
    await faceapi.nets.tinyFaceDetector.loadFromUri("/models");
    await faceapi.nets.faceLandmark68Net.loadFromUri("/models");
    await faceapi.nets.faceRecognitionNet.loadFromUri("/models");
  };

  const capture = async () => {
    try {
      await loadModels();
      const imageSrc = webcamRef.current.getScreenshot();
      const image = await faceapi.fetchImage(imageSrc);
      const detections = await faceapi
        .detectAllFaces(image)
        .withFaceLandmarks()
        .withFaceDescriptors();
      if (detections.length > 0) {
        onCapture(imageSrc);
      } else {
        alert("No face detected.");
      }
    } catch (error) {
      console.error("Error capturing image:", error);
    }
  };

  return (
    <div>
      <Webcam
        audio={false}
        ref={webcamRef}
        screenshotFormat="image/jpeg"
        width={320}
        height={240}
        videoConstraints={{
          width: 1280,
          height: 720,
          facingMode: "user",
        }}
      />
      <button onClick={capture}>Capture</button>
    </div>
  );
};

export default FaceRecognition;
