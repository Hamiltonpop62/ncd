import axios from "axios";
import React, { useState, useEffect } from "react";
import { Button, Col, Form, InputGroup, Row, Modal } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Header from "./Header";
import ApprovalModal from "./ApprovalModal";

const PatientsList = () => {
  const [patients, setPatients] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [selectedPatientId, setSelectedPatientId] = useState("");
  const [patientApprovalStatus, setPatientApprovalStatus] = useState({});
  const [error, setError] = useState(null);
  const[message,setMessage] = useState("");

  useEffect(() => {
    const fetchPatients = async () => {
      try {
        const userData = JSON.parse(localStorage.getItem("userData"));
        if (!userData) {
          window.location.href = "loginphp";
        }
        const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
        const apiResponse = await axios.post(
          apiUrl,
          {
            getPatientList: true,
            username: userData.username,
            searchDetails: searchQuery,
            patient_id: "",
            type: userData.userlevel,
          },
          {
            headers: {
              AuthKey: userData.token,
              Username: userData.username,
            },
          }
        );
        console.log(userData);
        if (apiResponse.data.result === "success") {
          setPatients(apiResponse.data.data);
        } else {
          console.error("Failed to fetch patients:", apiResponse.data.error);
          setMessage(apiResponse.data.error)
        }
        setIsLoading(false);
      } catch (error) {
        console.error("Error calling the API:", error);
        setIsLoading(false);
      }
    };

    fetchPatients();
    console.log(patients);
  }, [searchQuery]);

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const openModal = (patientId) => {
    setShowModal(true);
    setSelectedPatientId(patientId);
    console.log(selectedPatientId);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedPatientId("");
  };

  const handleApproval = async (reason, approval) => {
    try {
      const userData = JSON.parse(localStorage.getItem("userData"));
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const apiResponse = await axios.post(
        apiUrl,
        {
          PatientApproval: true,
          username: userData.username,
          patient_id: selectedPatientId,
          approval: approval,
          reason: reason,
        },
        {
          headers: {
            AuthKey: userData.token,
            Username: userData.username,
          },
        }
      );
      console.log(apiResponse.data);
      closeModal();
      if (
        apiResponse.data.result === "Success" ||
        apiResponse.data.approval === 1
      ) {
        const updatedpatients = patients.map((patient) => 
          patient.patient_id === selectedPatientId
          ?{...patient,approval:1}
          :patient
        )
        setPatients(updatedpatients);
        setPatientApprovalStatus(apiResponse.data.result);
      } else {
        console.error("Failed approval patients:", apiResponse.data.error);
        setError(apiResponse.data.error);
      }
    } catch (error) {
      console.error("Error calling the API:", error);
    }
  };
  const handleAcceptRegistration = async (patientId) => {
    try {
      const userData = JSON.parse(localStorage.getItem("userData"));
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const apiResponse = await axios.post(
        apiUrl,
        {
          AcceptpatientRegistration: true,
          username: userData.username,
          patient_id: patientId,
          type: userData.userlevel,
          relation_type: "",
          husband_or_father_name: "",
          district: "",
          mandal_code: "",
          village_code: "",
          address: "",
        },
        {
          headers: {
            AuthKey: userData.token,
            Username: userData.username,
          },
        }
      );
      console.log(apiResponse.data);
      if (apiResponse.data.result === "Beds Data Updated Successfully") {
      } else {
        console.error(
          "Failed to accept patient registration:",
          apiResponse.data.error
        );
        setError(apiResponse.data.error);
      }
    } catch (error) {
      console.error("Error calling the API:", error);
    }
  };
  const timer = setTimeout(() => {
    setError(null);
  }, 5000);

  return (
    <div>
      <Header/>
      {error && <div className="alert alert-danger">{error}</div>}
      <div className="px-4 d-flex mt-3 mb-4">
        <Col md={5}>
          <div className="text3">Patient List</div>
        </Col>
        <Col md={7}>
          <div className="d-flex align-items-center">
            <div className="col-md-3">
              <Form.Group
                className=""
                controlId="formBasicCheckbox"
                id="formBasicCheckbox"
              >
                <Form.Check
                  type="checkbox"
                  label="View Current In-Patients"
                  className="f14"
                />
              </Form.Group>
            </div>

            <div className="col-md-5">
              <InputGroup className=" ps-3">
                <Form.Control
                  placeholder="Search patient by Aaadhar"
                  aria-label="Recipient's username"
                  aria-describedby="basic-addon2"
                  className="f14"
                  value={searchQuery}
                  onChange={handleSearchChange}
                />
                <InputGroup.Text id="basic-addon2" className="bg1">
                  Search
                </InputGroup.Text>
              </InputGroup>
            </div>
            <div className="ps-3 col-md-4">
              <a
                href="/patientregistration"
                className="btn1 px-4 py-2 text-white text-decoration-none"
              >
                Register New Patient
              </a>
            </div>
          </div>
        </Col>
      </div>
      {isLoading ? (
        <div className="text-center">
          <div className="spinner-border mt-5" role="status"></div>
          <div className="">Loading...</div>
        </div>
      ) : (
        <div className="px-4 pt-3" id="tabs1">
          <table className="table table-striped shadow-sm">
            <thead>
              <tr>
                <th className="bg1">Sno</th>
                <th className="bg1">Patient ID</th>
                <th className="bg1">Name</th>
                <th className="bg1">Aaadhar</th>
                <th className="bg1">Mobile No</th>
                <th className="bg1">Referred Date</th>
                <th className="bg1">Referred By</th>
                <th className="bg1">Patient Approval/Reject</th>
                <th className="bg1">Accept Registration </th>
              </tr>
            </thead>
            <tbody>
            {patients.length > 0 ? (
              <>
              {patients.map((patient, index) => (
                <tr key={patient.patient_id}>
                  <td>{index + 1}</td>
                  <td>NSD{patient.patient_id}</td>
                  <td>{patient.patient_name}</td>
                  <td>{patient.aadhar}</td>
                  <td>{patient.mobile_number}</td>
                  <td>{patient.refer_date}</td>
                  <td>
                    {patient.referred_by && patient.referred_by.length > 0 ? (
                      <div>{patient.referred_by}</div>
                    ) : (
                      <div>----</div>
                    )}
                  </td>

                  <td>

                  {error === "Patient Already Approved or Rejected" ? (
                      <div>Approved</div>
                    ) : (
                      <Button
                        onClick={() => openModal(patient.patient_id)}
                        className="bg1">
                        Approve/Reject
                      </Button>
                    )}
                  </td>
                  <td>
                    <Button
                      onClick={() =>
                        handleAcceptRegistration(patient.patient_id)
                      }>
                      Accept Registration
                    </Button>
                  </td>
                </tr>
              ))}
              </>
            ):(
<td className="text-center pt-5 pb-5" colspan="9">{message}</td>
            )}
            </tbody>
          </table>
        </div>
      )}
<ApprovalModal 
showModal={showModal}
closeModal={closeModal}
selectedPatientId={selectedPatientId}
handleApproval={handleApproval}
/>
    </div>
  );
};

export default PatientsList;
