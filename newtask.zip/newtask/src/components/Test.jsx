import React, { useState } from "react";

const Test = () => {
  const SLIDES = [
    {
      title: "Today's workout plan",
      text: "We're gonna do 3 fundamental exercises.",
    },
    {
      title: "First, 10 push-ups",
      text: "Do 10 reps. Remember about full range of motion. Don't rush.",
    },
    {
      title: "Next, 20 squats",
      text: "Squats are important. Remember to keep your back straight.",
    },
    {
      title: "Finally, 15 sit-ups",
      text: "Slightly bend your knees. Remember about full range of motion.",
    },
    {
      title: "Great job!",
      text: "You made it, have a nice day and see you next time!",
    },
  ];
  const [currentSlide, setcurrentSlide] = useState(0);

  const nextSlide = () => {
    setcurrentSlide(currentSlide + 1);
  };
  const prevSlide = () => {
    setcurrentSlide(currentSlide - 1);
  };

  const restartSlide = () => {
    setcurrentSlide(0);
  };
  console.log(
    SLIDES[currentSlide].title,
    SLIDES[currentSlide].text,
    currentSlide
  );
  return (
    <div>
      <button
        data-testid="button-restart"
        className="small outlined"
        onClick={restartSlide}
        disabled={currentSlide == 0}
      >
        Restart
      </button>
      <button
        data-testid="button-prev"
        className="small"
        onClick={prevSlide}
        disabled={currentSlide == 0}
      >
        Prev
      </button>
      <button
        data-testid="button-next"
        className="small"
        onClick={nextSlide}
        disabled={currentSlide == SLIDES.length - 1}
      >
        Next
      </button>
  {/* map funct*/}
      {SLIDES.map((slide, index) => {
        return (
          <div
            key={index}
            style={{
              display: index === currentSlide ? "block" : "none",
            }}
          >
            <h1 data-testid="title">{slide.title}</h1>
            <p data-testid="text">{slide.text}</p>
          </div>
        );

      }
        )}
    </div>
  );
};

export default Test;
