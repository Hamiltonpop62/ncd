import axios from "axios";
import React, { useState, useEffect } from "react";
import { Button, Col, Form, InputGroup, Row } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Header from "./Header";

const PatientDiagnosis = () => {
  const userData = JSON.parse(localStorage.getItem("userData"));
  const patientid = JSON.parse(localStorage.getItem("patientId"));
  const [message, setMessage] = useState("");
  const [districts, setDistricts] = useState([]);
  const[facilities,setFacilities] = useState([]);
  const [formData, setFormData] = useState({
    pid: patientid.patid,
    username: userData.username,
    diagnosis: "",
    complication: "",
    care_id: "",
    surgery: "",
    surgery_others: "",
    referral_district: "",
    referral_facility: "",
    discharge_plan: "",
  });

  useEffect(() => {
    const userData = JSON.parse(localStorage.getItem("userData"));
    const patientid = JSON.parse(localStorage.getItem("patientId"));
    if (!userData || !patientid) {
      window.location.href = "loginphp";
    }

    // Fetch districts data
    const fetchDistricts = async () => {
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const apiResponse = await axios.post(
        apiUrl,
        {
          getDistricts: true,
          username: userData.username,
        },
        {
          headers: {
            AuthKey: userData.token,
            Username: userData.username,
          },
        }
      );

      if (apiResponse.data.result === "success") {
        console.log("districts Fetched successfully:", apiResponse.data);
        setDistricts(apiResponse.data.data);
      } else {
        console.error("Failed to fetch:", apiResponse.data.error);
      }
    };

    fetchDistricts();
  }, []);

  const handleDistrictChange = async (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });

    // Fetch facilities based on the selected district
    const fetchFacilities = async () => {
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const apiResponse = await axios.post(
        apiUrl,
        {
          getFacilities: true,
          username: userData.username,
          district_code: value,
        },
        {
          headers: {
            AuthKey: userData.token,
            Username: userData.username,
          },
        }
      );

      if (apiResponse.data.result === "success") {
        console.log("Facilities fetched successfully:", apiResponse.data);
        setFacilities(apiResponse.data.data);
      } else {
        console.error("Failed to fetch facilities:", apiResponse.data.error);
      }
    };
    fetchFacilities();
  };
  useEffect(() => {
    const userData = JSON.parse(localStorage.getItem("userData"));
    const patientid = JSON.parse(localStorage.getItem("patientId"));
    if (!userData || !patientid) {
      window.location.href = "loginphp";
    }
  }, []);
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const apiResponse = await axios.post(
        apiUrl,
        {
          SubmitPatientDiagnosis: true,
          ...formData,
        },
        {
          headers: {
            AuthKey: userData.token,
            Username: userData.username,
          },
        }
      );

      if (apiResponse.data.result === "Success") {
        console.log("Patient Details Added successfully:", apiResponse.data);

        setMessage("Patient Details Added successfully");
      } else {
        console.error("Failed to register patient:", apiResponse.data.error);
        setMessage("Patient Details Not  Added ");
      }
    } catch (error) {
      console.error("Error calling the API:", error);
    }
    console.log(formData);
  };
  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };
  return (
    <div>
      <Header />
      {message == "Patient Details Added successfully" ? (
        <div className="alert alert-success">{message}</div>
      ) : message === "Patient Details Not Added" ? (
        <div className="alert alert-danger">Patient Details Not Added</div>
      ) : (
        <div></div>
      )}
      <div className="text3 mt-4 mb-3 ps-3">Patient Diagnosis</div>
      <div className="row px-3 col-md-11 mt-5">
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Patient ID
            </label>
            <input
              type="text"
              name="pid"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={patientid.patid}
              disabled
            />
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Diagnosis
            </label>
            <input
              type="text"
              name="diagnosis"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.diagnosis}
              onChange={handleChange}
            />
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Complication
            </label>
            <input
              type="text"
              name="complication"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.complication}
              onChange={handleChange}
            />
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Care Data
            </label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="care_id"
              value={formData.care_id}
              onChange={handleChange}
            >
              <option selected>Select</option>
              <option value="1">IV Antibiotics</option>
              <option value="2">RT Feeds</option>
              <option value="3">Physiotherapy</option>
              <option value="4">
                Respiratory Therapy(Suctionin,Chest Percussion)
              </option>
              <option value="5">Others</option>
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Refferal District
            </label>

            <select
              className="form-select"
              aria-label="Default select example"
              name="referral_district"
              value={formData.referral_district}
              onChange={handleDistrictChange}
            >
              <option selected>Select</option>
              {districts.map((district) => (
                <option key={district.id} value={district.lgd_code}>
                  {district.district}
                </option>
              ))}
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3 ps-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Referral Facility
            </label>
            <select
            className="form-select"
            aria-label="Default select example"
            name="referral_facility"
            value={formData.referral_facility}
            onChange={handleChange}
          >
            <option value="">Select</option>
            {facilities.map((facility) => (
              <option key={facility.id} value={facility.id}>
                {facility.facility}
              </option>
            ))}
          </select>
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Discharge Plan
            </label>
            <input
              type="text"
              name="discharge_plan"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.discharge_plan}
              onChange={handleChange}
            />
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <Button
            type="submit"
            className="btn1 px-5 py-2"
            onClick={handleSubmit}
          >
            Submit
          </Button>
        </Col>
      </div>
    </div>
  );
};

export default PatientDiagnosis;
