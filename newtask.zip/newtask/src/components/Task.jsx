import React from "react";
import { Image } from "react-bootstrap";
import img1 from "../images/bg1.svg";
import img2 from "../images/bg2.png";

const Task = () => {   
  return (
    <div className="bg4 h-100">
      <div className="bg2 text-center ft1">Hurrahhh...</div>
      <div className="bg3 text-center ft2">You completed your assessment!</div>
      <div className="text-center d-flex">
      <div className="col-md-2"></div>
      <div className="col-md-7">
        <Image src={img1} alt="" className="w-100"/>
        </div>
        <div className="col-md-3">
        <Image src={img2} alt="" className="w-100 h-100"/>
        </div>
      </div>
    </div>
  );
};

export default Task;
