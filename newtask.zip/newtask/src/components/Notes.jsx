import React, { useState } from "react";
import { Button, Form, Col, Card } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { addNote } from "../redux/slices/noteSlice";
import DeleteNotes from "./DeleteNotes";

const Notes = () => {
  const [data, setData] = useState({ title: "", description: "" });
  const dispatch = useDispatch();
  const handleInput = (e) => {
    const { name, value } = e.target;
    setData({ ...data, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (data.title !== "" && data.description !== "") {
      dispatch(addNote(data));
    } else {
      alert("Please fill the form");
    }
    setData({ title: "", description: "" });
    console.log(data);
  };
  return (
    <div className="font mt-5">
      <Col md={6} className="mx-auto">
        <Card className="shadow-sm px-3 py-3">
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                name="title"
                value={data.title}
                onChange={handleInput}
                placeholder="Enter Title"
              />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>Notes</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="description"
                value={data.description}
                onChange={handleInput}
                placeholder="Enter Notes"
              />
            </Form.Group>
            <Form.Group>
            <Form.Label style={{position:"relative",bottom:"7px"}}>Category</Form.Label>
            <Form.Control as="select" name="category" onChange={handleInput}>
              <option>Personal</option>
              <option>Work</option>
              <option>Others</option>
            </Form.Control>
            </Form.Group>
            <Button variant="outline-success" type="submit">
              + Add Notes
            </Button>
          </Form>
        </Card>
        <DeleteNotes />
      </Col>
    </div>
  );
};

export default Notes;
