import React, { useState } from "react";
import ReactDOM from "react-dom";
import GoogleLogin from "react-google-login";

const Signups = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState({});

  const handleLogin = (response) => {
    setIsAuthenticated(true);
    setUser(response.profileObj);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser({});
  };
  console.log(user, "user");
  if (isAuthenticated) {
    return (
      <div>
        <h1>Welcome, {user.name}!</h1>
        <p>Your email address is {user.email}.</p>
        <p>Your contacts are:</p>
        {user.contacts.map((contact) => (
          <div key={contact.id}>
            {contact.name}
            {contact.email}
          </div>
        ))}
        <button onClick={handleLogout}>Logout</button>
      </div>
    );
  } else {
    return (
      <div>
        <GoogleLogin
          clientId="281619176059-qq7pnm6inalc6e47p706v912rvqck09p.apps.googleusercontent.com"
          buttonText="Sign in with Google"
          onSuccess={handleLogin}
        />
      </div>
    );
  }
};

export default Signups;
