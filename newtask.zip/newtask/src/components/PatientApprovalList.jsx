import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Button,
  Col,
  Form,
  InputGroup,
  Row,
  Modal,
  Table,
} from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Header from "./Header";
import moment from "moment";

const PatientApprovalList = () => {
  const [patients, setPatients] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showsModal, setShowsModal] = useState(false);
  const [dischargeModal, setDischargeModal] = useState(false);
  const [remarks, setRemarks] = useState();
  const [selectedPatientId, setSelectedPatientId] = useState(null);
  const [imageFiles, setImageFiles] = useState();
  const [serviceData, setServiceData] = useState([]);
  const[dischargemessage,setDischargemessage]= useState();
  const[serviceerror,setServiceerror] = useState("");
  useEffect(() => {
    const fetchPatients = async () => {
      try {
        const userData = JSON.parse(localStorage.getItem("userData"));
        if (!userData) {
          window.location.href = "loginphp";
        }
        const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
        const apiResponse = await axios.post(
          apiUrl,
          {
            ApprovalPatientList: true,
            username: userData.username,
            searchDetails: searchQuery,
            type: userData.userlevel,
          },
          {
            headers: {
              AuthKey: userData.token,
              Username: userData.username,
            },
          }
        );
        console.log(userData);
        if (apiResponse.data.result === "success") {
          setPatients(apiResponse.data.data);
        } else {
          console.error("Failed to fetch patients:", apiResponse.data.error);
        }
        setIsLoading(false);
      } catch (error) {
        console.error("Error calling the API:", error);
        setIsLoading(false);
      }
    };

    fetchPatients();
    console.log(patients);
  }, [searchQuery]);

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };
  const handleAddService = (patientId) => {
    // Handle add service button click
    setSelectedPatientId(patientId);

    setShowModal(true);
  };

  const handleDischarge = (patientId) => {
    console.log("Selected Patient ID:", patientId); // Add this line
    setSelectedPatientId(patientId);
    setDischargeModal(true);
  };

  const handleImageUpload = async () => {
    try {
      const userData = JSON.parse(localStorage.getItem("userData"));
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const currentDate = moment().format("YYYY-MM-DD");
      const imageUrl = "http://localhost/Ncd/mobile/files/" + imageFiles;
      console.log("Current Date:", currentDate); // Log currentDate
      console.log("Image Files:", imageFiles);
      const formData = new FormData();
      formData.append("AddService", true);
      formData.append("username", userData.username);
      formData.append("patient_id", selectedPatientId);
      formData.append("date_service", currentDate);
      formData.append("image", imageUrl);

      const apiResponse = await axios.post(apiUrl, formData, {
        headers: {
          "Content-Type": "application/json",
          AuthKey: userData.token,
          Username: userData.username,
        },
      });

      if (apiResponse.data.result === "success") {
        // Handle success response, update patient data if needed
      } else {
        console.error("Failed to upload images:", apiResponse.data.error);
      }
    } catch (error) {
      console.error("Error calling the API:", error);
    }
  };

  const handleDischarges = async () => {
    try {
      const userData = JSON.parse(localStorage.getItem("userData"));
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const formData = new FormData();
      formData.append("PatientDischarge", true);
      formData.append("username", userData.username);
      formData.append("patient_id", selectedPatientId.toString());
      formData.append("type", userData.userlevel);
      formData.append("remarks", remarks);

      const apiResponse = await axios.post(apiUrl, formData, {
        headers: {
          "Content-Type": "application/json",
          AuthKey: userData.token,
          Username: userData.username,
        },
      });

      if (apiResponse.data.result === "Patient Discharged Successfully") {
        setDischargemessage("Patient Discharged Successfully");
      } else {
        console.error("Failed to Discharge:", apiResponse.data.error);
        setDischargemessage("failed")
      }
    } catch (error) {
      console.error("Error calling the API:", error);
    }
  };

  const handleViewService = async (patientId) => {
    try {
      const userData = JSON.parse(localStorage.getItem("userData"));
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const formData = new FormData();
      formData.append("ViewService", true);
      formData.append("username", userData.username);
      formData.append("patient_id", patientId);

      const apiResponse = await axios.post(apiUrl, formData, {
        headers: {
          "Content-Type": "application/json",
          AuthKey: userData.token,
          Username: userData.username,
        },
      });

      if (apiResponse.data.result === "Success") {
        // Handle success response, update patient data if needed
        setServiceData(apiResponse.data.data);
        setShowsModal(true);
      } else {
        console.error("Failed to view service:", apiResponse.data.error);
        setServiceerror(apiResponse.data.error);
      }
      console.log(apiResponse.data);
    } catch (error) {
      console.error("Error calling the API:", error);
    }
  };

  const handleChange = (e) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setImageFiles(files[0].name); // Store the file object directly
    }
    console.log("Image Files:", imageFiles);
  };

  const handleremarks = (e) => {
    setRemarks(e.target.value);
  };

  return (
    <div>
      <Header />
      {serviceerror.length>0?(
        <div className="alert alert-danger mt-1">{serviceerror}</div>
      ):(
        ""
      )
      }
      {isLoading ? (
        <div className="text-center">
          <div className="spinner-border mt-5" role="status"></div>
          <div className="">Loading...</div>
        </div>
      ) : (
        <React.Fragment>
          <div className="col-md-3 mt-4">
            <InputGroup className=" ps-3">
              <Form.Control
                placeholder="Search patient by Aaadhar"
                aria-label="Recipient's username"
                aria-describedby="basic-addon2"
                className="f14"
                value={searchQuery}
                onChange={handleSearchChange}
              />
              <InputGroup.Text id="basic-addon2" className="bg1">
                Search
              </InputGroup.Text>
            </InputGroup>
          </div>

          <div className="px-4 pt-3" id="tabs1">
            <table className="table table-striped shadow-sm">
              <thead>
                <tr>
                  <th className="bg1">Sno</th>
                  <th className="bg1">Patient ID</th>
                  <th className="bg1">Name</th>
                  <th className="bg1">Aaadhar</th>
                  <th className="bg1">Mobile No</th>
                  <th className="bg1">Referred By</th>
                  <th className="bg1">Patient Approval/Reject</th>
                  <th className="bg1">Status</th>
                  <th className="bg1">Add Service</th>
                  <th className="bg1">View Service</th>
                  <th className="bg1">Discharge</th>
                  {/* Add more table headers as needed */}
                </tr>
              </thead>
              <tbody>
                {patients.map((patient, index) => (
                  <tr key={patient.patient_id}>
                    <td>{index + 1}</td>
                    <td>NSD{patient.patient_id}</td>
                    <td>{patient.patient_name}</td>
                    <td>{patient.aadhar}</td>
                    <td>{patient.mobile_number}</td>
                    <td>
                      {patient.referred_by && patient.referred_by.length > 0 ? (
                        <div>{patient.referred_by}</div>
                      ) : (
                        <div>----</div>
                      )}
                    </td>
                    <td>{patient.reason_for_Accept_Reject}</td>
                    <td>{patient.status}</td>

                    <td>
                      <Button
                        onClick={() => {
                          console.log("Patient ID:", patient.patient_id); // Add this line
                          handleAddService(patient.patient_id);
                        }}
                      >
                        Add Service
                      </Button>
                    </td>
                    <td>
                      <Button
                        onClick={() => {
                          console.log("Patient ID:", patient.patient_id);
                          handleViewService(patient.patient_id);
                        }}
                      >
                        View Service
                      </Button>
                    </td>
                    <td>
                      <Button
                        onClick={() => {
                          console.log("Patient ID:", patient.patient_id); // Add this line
                          handleDischarge(patient.patient_id);
                        }}
                      >
                        Discharge
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Modal show={showModal} onHide={() => setShowModal(false)}>
            <Modal.Header closeButton>
              <Modal.Title>Add Service</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form encType="multipart/form-data">
                <Form.Group controlId="formFileMultiple" className="mb-3">
                  <Form.Label>Upload Images</Form.Label>
                  <Form.Control type="file" multiple onChange={handleChange} />
                </Form.Group>
              </Form>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowModal(false)}>
                Close
              </Button>
              <Button variant="primary" onClick={handleImageUpload}>
                Upload
              </Button>
            </Modal.Footer>
          </Modal>

          <Modal show={showsModal} onHide={() => setShowsModal(false)}>
            <Modal.Header closeButton>
              <Modal.Title>View Service</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Table striped bordered hover>
                <thead>
                  <tr>
                    <th>Date of Service</th>
                    <th>Username</th>
                    <th>Drug Images</th>
                  </tr>
                </thead>
                <tbody>
                  {serviceData.map((item, index) => (
                    <tr key={index}>
                      <td>{item.date_service}</td>
                      <td>{item.username}</td>
                      <td>{item.drug_images ? item.drug_images : "---"}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowsModal(false)}>
                Close
              </Button>
            </Modal.Footer>
          </Modal>

          <Modal show={dischargeModal} onHide={() => setDischargeModal(false)}>
            <Modal.Header closeButton>
              <Modal.Title>Discharge</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            {
              dischargemessage
              ==="Patient Discharged Successfully"
              ? (
                <div className="alert alert-success" role="alert">
                  Patient Discharged successfully 
                </div>
              )
              :
             (
              dischargemessage==="failed"
              ? (
                <div className="alert alert-danger" role="alert">
                  Failed to Discharge
                </div>
              )
              :null
              
            )}
              <Form encType="multipart/form-data">
                <Form.Group controlId="formFileMultiple" className="mb-3">
                  <Form.Label>Remarks</Form.Label>
                  <Form.Control
                    type="text"
                    name="remarks"
                    onChange={handleremarks}
                  />
                </Form.Group>
              </Form>
            </Modal.Body>
            <Modal.Footer>
              <Button
                variant="secondary"
                onClick={() => setDischargeModal(false)}
              >
                Close
              </Button>
              <Button variant="primary" onClick={handleDischarges}>
                Submit
              </Button>
            </Modal.Footer>
          </Modal>
        </React.Fragment>
      )}
    </div>
  );
};

export default PatientApprovalList;
