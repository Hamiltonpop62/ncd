import axios from "axios";
import React, { useState, useEffect } from "react";
import { Button, Col, Form, InputGroup, Row } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Header from "./Header";
import moment from "moment";


const PatientRegistration = () => {
  const userData = JSON.parse(localStorage.getItem("userData"));
  const [aadharError, setAadharError] = useState("");
  const [mobilenoError, setMobilenoError] = useState("");
  const[PatientnameError,setPatientnameError]=useState("");
  const [formData, setFormData] = useState({
    patientRegistration: true,
    patient_name: "",
    aadhar: "",
    mobile: "",
    dob: "",
    age: "",
    date_of_registration: "",
    gender: "",
    district: "",
    mandal_code: "",
    village_code: "",
    image: [],
    relation_type: "",
    husband_or_father_name: "",
    address: "",
    specialist_type: userData.userlevel,
    discharge_image: [],
    username: userData.username,
    del_flag:"1",
    reject_flag:"0",
    status:"0" 
  });
  const [registrationId, setRegistrationId] = useState("");
  const [registrationResult, setRegistrationResult] = useState("");
  useEffect(() => {
    const userData = JSON.parse(localStorage.getItem("userData"));
    if (!userData) {
      window.location.href = "loginphp";
    }
  }, []);
  const handleSubmit = async (event) => {
    event.preventDefault();
    if (aadharError) {
      console.log("Cannot submit form due to errors");
      return;
    }
    try {
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const apiResponse = await axios.post(
        apiUrl,
        {
          patientRegistration: true,
          ...formData,
        },
        {
          headers: {
            AuthKey: userData.token,
            Username: userData.username,
          },
        }
      );

      if (apiResponse.data.result === "success") {
        console.log("Patient registered successfully:", apiResponse.data);
        setRegistrationId(apiResponse.data.id);
        localStorage.setItem("patientId", JSON.stringify({ patid: apiResponse.data.id }));
        setRegistrationResult("success"); 
      } else {
        console.error("Failed to register patient:", apiResponse.data.error);
        setRegistrationResult("failed"); 
      }
    } catch (error) {
      console.error("Error calling the API:", error);
      setRegistrationResult("error"); 
    }
    console.log(formData);
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
    if (name === "aadhar") {
      const aadharRegex = /^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$/;
      if (!aadharRegex.test(value)) {
        setAadharError("Invalid Aadhar number");
      } else {
        setAadharError("");
      }
    }else if(name === "mobile"){
      const mobileRegex = /^[6-9]\d{9}$/;
      if (!mobileRegex.test(value)) {
        setMobilenoError("Invalid Mobile number");
      } else {
        setMobilenoError("");
      }
    } else    if (name === "dob") {
      const formattedDate = moment(value, "YYYY-MM-DD");
      const today = moment();
      const age = today.diff(formattedDate, "years");
      setFormData((prevFormData) => ({ ...prevFormData, age: age.toString() }));
    } else if(name === "patient_name"){
      const patientNameRegex = /^[a-zA-Z\s]+$/;
      if (!patientNameRegex.test(value)) {
        setPatientnameError("Invalid Patient Name");
      } else {
        setPatientnameError("");
      }
    }
  };
  return (
    <div>
<Header/>
   {
    registrationResult==="success"
    ? (
      <div className="alert alert-success" role="alert">
        Patient registered successfully with ID: {registrationId}
      </div>
    )
    :
   (
    registrationResult==="failed"
    ? (
      <div className="alert alert-danger" role="alert">
        Failed to register patient. Please try again.
      </div>
    )
    :null
    
  )}
      <div className="text3 mt-4 mb-3 ps-3">Patient Registration</div>
      <div className="row px-3 col-md-11 mt-5">
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Patient Name
            </label>
            <input
              type="text"
              name="patient_name"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.patient_name}
              onChange={handleChange}
            />
          </div>
          {PatientnameError && <div style={{ color: "red" }}>{PatientnameError}</div>}
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Aadhar Number
            </label>
            <input
              type="number"
              name="aadhar"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.aadhar}
              onChange={handleChange}
            />
          </div>
          {aadharError && <div style={{ color: "red" }}>{aadharError}</div>}
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Mobile Number
            </label>
            <input
              type="text"
              name="mobile"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.mobile}
              onChange={handleChange}
            />
          </div>
          {mobilenoError && <div style={{ color: "red" }}>{mobilenoError}</div>
            }
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Date Of Birth
            </label>
            <input
              type="date"
              name="dob"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.dob}
              onChange={handleChange}
            />
          </div>
        </Col>

        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Age
            </label>
            <input
              type="text"
              name="age"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.age}
              onChange={handleChange}
              disabled={true}
            />
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Date Of Registration
            </label>
            <input
              type="date"
              name="date_of_registration"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.date_of_registration}
              onChange={handleChange}
            />
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Gender
            </label>
            <select class="form-select" aria-label="Default select example" name="gender"  value={formData.gender}
            onChange={handleChange}>
              <option selected>Select</option>
              <option value="1">Male</option>
              <option value="2">Female</option>
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Relation Type
            </label>
            <select class="form-select" aria-label="Default select example" name="relation_type"  value={formData.relation_type}
            onChange={handleChange}>
              <option selected>Select</option>
              <option value="1">W/O</option>
              <option value="2">S/O</option>
              <option value="2">D/O</option>
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Husband Or Father Name
            </label>
            <input
              type="text"
              name="husband_or_father_name"
              className="form-control"
              placeholder="Enter "
              autoComplete="off"
              value={formData.husband_or_father_name}
              onChange={handleChange}
            />
          </div>
        </Col>

        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Village
            </label>
            <select class="form-select" aria-label="Default select example" name="village_code"
            value={formData.village_code}
            onChange={handleChange}
            >
              <option selected>Select</option>
              <option value="200000015">BIBINAGAR</option>
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Mandal
            </label>
            <select class="form-select" aria-label="Default select example" name="mandal_code"
            value={formData.mandal_code}
              onChange={handleChange}>
              <option selected>Select</option>
              <option value="6223">BHEEMPOOR</option>
            </select>
          </div>
        </Col>

        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              District
            </label>
            <select class="form-select" aria-label="Default select example" name="district"
            value={formData.district} 
              onChange={handleChange}>
              <option selected>Select</option>
              <option value="501">Adilabad</option>
              <option value="699">Komarambheem Asifabad</option>
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Patient Photo
            </label>
            <input type="file" className="form-control" name="image"
            value={formData.image} onChange={handleChange}/>
          </div>
        </Col>
        <Col md={3} className="mb-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Admission Approved By
            </label>
            <select class="form-select" aria-label="Default select example" 
            >
              <option selected>Select</option>
              <option value="1">DM</option>
              <option value="2">HM</option>
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3">
        <Button type="submit" className="btn1 px-5 py-2" onClick={handleSubmit}>Submit</Button>
        </Col>
      </div>
    </div>
  );
};

export default PatientRegistration;
