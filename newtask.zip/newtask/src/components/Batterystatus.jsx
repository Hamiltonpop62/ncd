import React, { useEffect, useState } from "react";
import { Image } from "react-bootstrap";
import Logo1 from "../images/time.png";
import battery1 from "../images/low-battery.png";
import battery2 from "../images/battery-status.png";
import battery3 from "../images/full-battery.png";
import battery4 from "../images/battery.png";
import check from "../images/check.png";
import reject from "../images/rejected.png";

const BatteryStatus = () => {
  const [batteryLevel, setBatteryLevel] = useState(0);
  const [charging, setCharging] = useState(false);
  const [chargingTime, setChargingTime] = useState(null);
  const [dischargingTime, setDischargingTime] = useState(null);
  useEffect(() => {
    navigator.getBattery().then((battery) => {
      setBatteryLevel(battery.level * 100);
      setCharging(battery.charging);
      setChargingTime(battery.chargingTime);
      setDischargingTime(battery.dischargingTime);
      battery.addEventListener("levelchange", () => {
        setBatteryLevel(battery.level * 100);
      });
      battery.addEventListener("chargingchange", () => {
        setCharging(battery.charging);
      });
      battery.addEventListener("chargingtimechange", () => {
        setChargingTime(battery.chargingTime);
      });
      battery.addEventListener("dischargingtimechange", () => {
        setDischargingTime(battery.dischargingTime);
      });
    });
  }, []);
  function updatebatterylevels() {
    if (batteryLevel < 20) {
      return <Image src={battery1} style={{ width: "75px", height: "75px" }} />;
    } else if (batteryLevel >= 20 && batteryLevel <= 80) {
      return <Image src={battery2} style={{ width: "75px", height: "75px" }} />;
    } else {
      return <Image src={battery4} style={{ width: "75px", height: "75px" }} />;
    }
  }

  function charginglevel() {
    if (charging) {
      return <Image src={battery3} style={{ width: "35px", height: "35px" }} />;
    } else {
      return <Image src={reject} style={{ width: "35px", height: "35px" }} />;
    }
  }
  updatebatterylevels();
  charginglevel();
  return (
    <React.Fragment>
      <div
        className="col-md-6 mx-auto p-4 mt-3"
        style={{ border: "1px solid #212121", borderRadius: "12px" }}
      >
        <div
          style={{ fontWeight: "600", fontSize: "24px", textAlign: "center" }}
          className="mb-3"
        >
          Battery Status
        </div>
        <div>
          <span>
            <b>Battery Level:</b>
          </span>
          <span className="ps-3">{batteryLevel.toFixed(1)}%</span>
          {updatebatterylevels()}
        </div>
        <div className="mb-3">
          <span>
            <b>Charging:</b>
          </span>
          <span>
            {" "}
            {charging ? "Yes" : "No"}
            {charginglevel()}
          </span>
        </div>
        <div className="mb-3">
          <span>
            <b>Charging Time:</b>
          </span>
          <span>
            {" "}
            {chargingTime === Infinity
              ? "Infinity"
              : chargingTime
              ? `${chargingTime} seconds`
              : "N/A"}
          </span>
        </div>
        <div className="mb-3">
          <span>
            <b>Discharging Time: </b>
          </span>
          <span>
            {dischargingTime === Infinity
              ? "Infinity"
              : dischargingTime
              ? `${dischargingTime} seconds`
              : "N/A"}
          </span>
        </div>
      </div>
    </React.Fragment>
  );
};

export default BatteryStatus;
