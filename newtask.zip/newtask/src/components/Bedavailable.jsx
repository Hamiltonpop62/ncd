import axios from "axios";
import React, { useState } from "react";
import { Button, Col, Table } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Header from "./Header";

const Bedavailable = () => {
  const [districtCode, setDistrictCode] = useState("");
  const [facilityCode, setFacilityCode] = useState("");
  const [bedsAvailability, setBedsAvailability] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [districtSelected, setDistrictSelected] = useState(false);

  const fetchBedsAvailability = async () => {
    try {
      setIsLoading(true);
      const userData = JSON.parse(localStorage.getItem("userData"));
      if (!userData) {
        window.location.href = "loginphp";
      }
      const apiUrl = "http://localhost/Ncd/mobile/mobile.php";
      const apiResponse = await axios.post(
        apiUrl,
        {
          bedsAvailability: true,
          username: userData.username,
          district_code: districtCode,
          facility_code: facilityCode,
        },
        {
          headers: {
            AuthKey: userData.token,
            Username: userData.username,
          },
        }
      );
      if (apiResponse.data.result === "success") {
        setBedsAvailability(apiResponse.data.data[0]);
      } else {
        console.error(
          "Failed to fetch beds availability:",
          apiResponse.data.error
        );
      }
      setIsLoading(false);
    } catch (error) {
      console.error("Error calling the API:", error);
      setIsLoading(false);
    }
  };

  const handleDistrictChange = (event) => {
    setDistrictCode(event.target.value);
    setFacilityCode("");
    setDistrictSelected(true);
  };

  const handleFacilityChange = (event) => {
    setFacilityCode(event.target.value);
  };

  const handleSubmit = () => {
    fetchBedsAvailability();
  };

  return (
    <div>
      <Header />
      <div className="px-4 d-flex pt-4">
        <Col md={3} className="mb-3 ">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              District
            </label>
            <select
              className="form-select"
              aria-label="Default select example"
              name="district"
              value={districtCode}
              onChange={handleDistrictChange}
            >
              <option value="">Select</option>
              <option value="501">Adilabad</option>
              <option value="684">Mancherial</option>
              <option value="507">Hyderabad</option>
              <option value="693">Wanaparthy</option>
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3 ps-3">
          <div className="form-group mb-3" id="id1">
            <label
              htmlFor="exampleInputEmail1 text1"
              style={{
                fontWeight: 500,
                fontSize: "15px",
              }}
              className="text2"
            >
              Facility
            </label>
            <select
              className="form-select"
              aria-label="Default select example"
              name="facility"
              value={facilityCode}
              onChange={handleFacilityChange}
              disabled={!districtSelected} // Disable if district not selected
            >
              <option value="">Select</option>
              {districtCode === "501" ? (
                <option value="16">RIMS Adilabad</option>
              ) : (
                ""
              )}
              {districtCode === "684" ? (
                <option value="17">GGH Manchiryal</option>
              ) : (
                ""
              )}
              {districtCode === "507" ? (
                <option value="1">MNJIO & Regional Cancer Center(Hyd) </option>
              ) : (
                ""
              )}
              {districtCode === "507" ? (
                <option value="2">
                  {" "}
                  Red Cross Building ,Gaddiannaram(Hyd)
                </option>
              ) : (
                ""
              )}
              {districtCode === "693" ? (
                <option value="3">GGH Wanaparthy</option>
              ) : (
                ""
              )}
            </select>
          </div>
        </Col>
        <Col md={3} className="mb-3 mt-3 ms-3">
          <Button
            variant="primary"
            className="btn1"
            onClick={handleSubmit}
            disabled={!districtCode || !facilityCode}
          >
            Submit
          </Button>
        </Col>
      </div>
      <div className="px-4 d-flex pt-4">
        <Col>
          {isLoading ? (
            <div className="text-center">Loading...</div>
          ) : (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th style={{ backgroundColor: "rgba(251, 217, 235, 1)" }}>
                    Sno
                  </th>
                  <th style={{ backgroundColor: "rgba(251, 217, 235, 1)" }}>
                    Beds
                  </th>
                  <th style={{ backgroundColor: "rgba(251, 217, 235, 1)" }}>
                    Value
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>Total Beds</td>
                  <td>{bedsAvailability.total_beds}</td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Beds Occupied</td>
                  <td>{bedsAvailability.beds_Occupied}</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Available Beds</td>
                  <td>{bedsAvailability.available_beds}</td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>Beds with Oxygen Support</td>
                  <td>{bedsAvailability.Beds_with_oxygen_support}</td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>Beds without Oxygen Support</td>
                  <td>{bedsAvailability.Beds_without_oxygen_support}</td>
                </tr>
              </tbody>
            </Table>
          )}
        </Col>
      </div>
    </div>
  );
};

export default Bedavailable;
