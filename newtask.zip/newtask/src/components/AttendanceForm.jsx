import React, { useState } from 'react';
import axios from 'axios';
import { useGeolocation } from 'react-geolocation';

const AttendanceForm = () => {
  const { latitude, longitude, timestamp, accuracy, error } = useGeolocation();
  const [faceImage, setFaceImage] = useState(null);

  const captureFace = (imageSrc) => {
    setFaceImage(imageSrc);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Send attendance data including latitude, longitude, and face image to the server
      await axios.post('http://localhost:3001/attendance', {
        userId: 1, // Assuming user ID 1 for simplicity
        date: new Date().toISOString(),
        latitude,
        longitude,
        faceImage
      });
      alert('Attendance marked successfully!');
    } catch (error) {
      console.error('Error marking attendance:', error);
      alert('Error marking attendance. Please try again.');
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <button type="submit">Mark Attendance</button>
      </form>
      <FaceRecognition onCapture={captureFace} />
    </div>
  );
};

export default AttendanceForm;
