import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteNote } from "../redux/slices/noteSlice";

const DeleteNotes = () => {
  const notes = useSelector((state) => state.note.notes);
  const dispatch = useDispatch();
  const handleDelete = (id) => {
    dispatch(deleteNote(id));
  };
  return (
    <div className="row">
      {notes.map((note) => {
        return (
          <div
            className="col-md-4 card shadow-sm mt-3  pt-2 pb-2 mx-1"
            key={note.id}
          >
            <h4 style={{ color: "#003cff", textTransform: "capitalize" }}>
              {note.title}
            </h4>
            <p>{note.description}</p>
            <button
              onClick={() => handleDelete(note.id)}
              className="btn btn-danger"
            >
              Delete
            </button>
          </div>
        );
      })}
    </div>
  );
};

export default DeleteNotes;
