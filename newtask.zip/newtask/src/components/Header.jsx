import React from "react";
import { Button, Col, Form, InputGroup, Row } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
const Header = () => {
    const hasPatientId = localStorage.getItem("patientId") !== null;

    const handlelogout = () => {
        localStorage.clear();
        window.location.href = "/loginphp";
    }

  return (
    <div>
      <Navbar expand="lg" className="bg1">
        <Container>
          <Navbar.Brand href="#home" className="text-white brand">
            NCD
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
            <Nav.Link href="/Bedavailable" className="text-white f14">
                Bed Availability
              </Nav.Link>
              <Nav.Link href="/patientlist" className="text-white f14">
                Patient List
              </Nav.Link>
              <Nav.Link href="/patientregistration" className="text-white f14">
                Patient Registration
              </Nav.Link>
              {hasPatientId && (
              <Nav.Link href="/patientdiagnosis" className="text-white f14">
                Patient Diagnosis
              </Nav.Link>
              )}
              <Nav.Link href="/patientapprovallist" className="text-white f14">
                Patient Approval List
              </Nav.Link>
              <Nav.Link href="#" className="text-white f14" onClick={handlelogout}>
                Logout
              </Nav.Link>
              
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
};

export default Header;
