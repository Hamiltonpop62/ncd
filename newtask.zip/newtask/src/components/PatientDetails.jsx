import React from 'react'

const PatientDetails = () => {
  return (
    <div>PatientDetails</div>
  )
}

export default PatientDetails