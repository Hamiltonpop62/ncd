import { Button } from 'bootstrap'
import React from 'react'
import { Form } from 'react-bootstrap'

const Pagination = () => {
  return (
    <div>
    <Form>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold Weight (gm)</Form.Label>
      <Form.Control type='number' placeholder='Gold Weight' />
      </Form.Group>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold Purity (%)</Form.Label>
      <Form.Control type='number' placeholder='Gold Purity' />
      </Form.Group>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold Price (Rs)</Form.Label>
      <Form.Control type='number' placeholder='Gold Price' />
      </Form.Group>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold Making Charges (Rs)</Form.Label>
      <Form.Control type='number' placeholder='Gold Making Charges' />
      </Form.Group>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold GST (%)</Form.Label>
      <Form.Control type='number' placeholder='Gold GST' />
      </Form.Group>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold Discount (%)</Form.Label>
      <Form.Control type='number' placeholder='Gold Discount' />
      </Form.Group>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold Wastage (%)</Form.Label>
      <Form.Control type='number' placeholder='Gold Wastage' />
      </Form.Group>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold Other Charges (%)</Form.Label>
      <Form.Control type='number' placeholder='Gold Other Charges' />
      </Form.Group>

      <Form.Group controlId="exampleForm.SelectCustom">
      <Form.Label>Gold Total Price (Rs)</Form.Label>
      <Form.Control type='number' placeholder='Gold Total Price' />
      </Form.Group>

      <Button variant="outline-primary" type="submit">Submit</Button>
    
    </Form>
    </div>
  )
}

export default Pagination