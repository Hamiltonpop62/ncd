// Signup.js
import React, { useState } from "react";
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import { Button, Col, Form } from "react-bootstrap";
import { Link, redirect } from "react-router-dom";

function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const auth = getAuth();
  const handleSignup = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password); // Updated function call
      setSuccessMessage("Signup successful");
      setTimeout(() => {
        setSuccessMessage(null);
      }, 5000);
      setEmail("");
      setPassword("");
    } catch (error) {
            if (error.code === "auth/email-already-in-use") {
            setErrorMessage(
                "This Email Address is already in use. "
            );
            setTimeout(() => {
                    setErrorMessage(null);
        }, 5000);
        } else if (error.code === "auth/invalid-email")  {
            setErrorMessage(
                "This Email Address is invalid. "
            );
            setTimeout(() => {
                    setErrorMessage(null);
        }, 5000);
        } else if (error.code === "auth/weak-password")  {
            setErrorMessage(
                "This Password is too weak. "
            );
            setTimeout(() => {
                    setErrorMessage(null);
        }, 5000);
        }else if (error.code === "auth/missing-password")  {
            setErrorMessage(
                "Enter Password. "
            );
            setTimeout(() => {
                    setErrorMessage(null);
        }, 5000);
        }
         else {

            
        
    }
      
      console.error(error);
    }
  };

  return (
    <div>
      <Col
        md={5}
        className="mx-auto mt-4 border-1 px-3 py-3 rounded"
        style={{ boxShadow: "-1px 2px 5px 5px #efefef" }}
      >
      {successMessage && <p className="alert alert-success" role="alert">{successMessage}</p>}
        {errorMessage && <p className="alert alert-danger" role="alert">{errorMessage}</p>}
        <h2 className="mb-3" style={{fontWeight:"600"}}>Sign Up</h2>

        <Form.Group controlId="formBasicEmail" className="mb-3">
          <Form.Label>Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Form.Group>
        <Form.Group controlId="formBasicEmail" className="mb-3">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Form.Group>
        <Button onClick={handleSignup}>Sign Up</Button>

        <div className="mt-3">
        <Link to="/login" className="mt-2">
          Already have an account? Login
        </Link>
        </div>
      </Col>
    </div>
  );
}

export default Signup;
