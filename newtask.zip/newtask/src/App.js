import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Notes from "./components/Notes";
import 'bootstrap/dist/css/bootstrap.min.css';
import "./App.css";
import Counter from "./components/Counter";
import ReactForm from "./components/ReactForm";
import Navigation from "./components/Login";
import { firebaseConfig } from "./firebase";
import { initializeApp } from "firebase/app";
import Signup from "./components/Signup";
import Signups from "./components/Signups";
import Pagination from "./components/Pagination";
import Weather from "./components/Weather";
import Batterystatus from "./components/Batterystatus";
import LocationDisplay from "./components/LocationDisplay";
import Loginphp from "./components/Loginphp";
import PatientsList from "./components/PatientsList";
import PatientRegistration from "./components/PatientRegistration";
import Bedavailable from "./components/Bedavailable";
import PatientDiagnosis from "./components/PatientDiagnosis";
import PatientDetails from "./components/PatientDetails";
import PatientApprovalList from "./components/PatientApprovalList";
import Task from "./components/Task";


function App() {
  initializeApp(firebaseConfig);
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/notes" element={<Notes />} />
          <Route path="/counter" element={<Counter />} />
          <Route path="/reactform" element={<ReactForm />} />
          <Route path="/login" element={<Navigation />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/signups" element={<Signups />} />
          <Route path="/" element={<Pagination />} />
          <Route path="/weather" element={<Weather />} />
          <Route path="/batterystatus" element={<Batterystatus />} />
          <Route path="/location" element={<LocationDisplay/>}/>
          <Route path="/loginphp" element={<Loginphp/>} />
          <Route path="/patientlist" element={<PatientsList/>}/>
          <Route path="/patientregistration" element={<PatientRegistration/>} />
          <Route path="/Bedavailable" element={<Bedavailable/>}/>
          <Route path="/patientdiagnosis" element={<PatientDiagnosis/>}/>
          <Route path="/patientdetails" element={<PatientDetails/>} />
          <Route path="/patientapprovallist" element={<PatientApprovalList/>} />
          <Route path="/task" element={<Task/>} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
